"""
This plugin searches for Azure Storage Account access keys.
"""
from __future__ import annotations

import re
from typing import Any
from typing import List
from typing import Optional
from typing import Set

from detect_secrets.core.potential_secret import PotentialSecret
from detect_secrets.plugins.base import RegexBasedDetector
from detect_secrets.util.code_snippet import CodeSnippet


class AzureStorageKeyDetector(RegexBasedDetector):
    """Scans for Azure Storage Account access keys."""
    secret_type = 'Azure Storage Account access key'

    account_key = r'account[_]?k(?:ey)?\b'
    account_key_check = re.compile(r'account[_]?k(?:ey)?\b', re.IGNORECASE)
    azure = 'azure'

    max_line_length = 4000
    max_part_length = 2000
    integrity_regex = re.compile(r'integrity[:=]|sha256|sha384|sha512|cosmos|master')

    denylist = [
        # Account Key (AccountKey=xxxxxxxxx)
        re.compile(
            r'(?:["\']?[A-Za-z0-9+\/]{86,88}==["\']?)',
        ),
    ]

    context_keys = [
        r'(?i){account_key}[\s=]{{1,20}}{secret}',

        # maximum 2 lines secret distance under azure mention (case-insensitive)
        r'(?i)\b{azure}(.*\n){{0,2}}.*{secret}',

        # maximum 2 lines secret distance above azure mention (case-insensitive)
        r'(?i)\b{secret}(.*\n){{0,2}}.*{azure}',
    ]

    def analyze_line(
            self,
            filename: str,
            line: str,
            line_number: int = 0,
            context: Optional[CodeSnippet] = None,
            raw_context: Optional[CodeSnippet] = None,
            **kwargs: Any,
    ) -> Set[PotentialSecret]:
        output: Set[PotentialSecret] = set()
        results = super().analyze_line(
            filename=filename, line=line, line_number=line_number,
            context=context, raw_context=raw_context, **kwargs,
        )
        output.update(self.analyze_context_keys(results, context, line, filename))

        return output

    def analyze_context_keys(
            self,
            results: Set[PotentialSecret],
            context: Optional[CodeSnippet],
            line: str,
            filename: str,
    ) -> List[PotentialSecret]:
        context_text = '\n'.join(context.lines).replace('\n\n', '\n') if context else line
        return [
            result for result in results if self.context_keys_exists(result, context_text) and
                self.should_analyze_file(filename)
        ]

    def should_analyze_file(self, filename: str) -> bool:
        excluded_files = {'tfplan.json', 'planfile.json'}
        return filename.split('/')[-1] not in excluded_files

    def context_keys_exists(self, result: PotentialSecret, string: str) -> bool:
        if len(string) > self.max_line_length:
            # for very long lines, we don't run the regex to avoid performance issues
            return False
        if result.secret_value:
            for secret_regex in self.context_keys:
                regex = re.compile(
                    secret_regex.format(
                        secret=re.escape(result.secret_value), account_key=self.account_key,
                        azure=self.azure,
                    ), re.MULTILINE,
                )
                if self.account_key in regex.pattern and not self.account_key_check.search(string):
                    continue
                if self.azure in regex.pattern.lower() and self.azure not in string.lower():
                    continue
                if self.contains_integrity(result.secret_value, string):
                    continue
                if regex.search(string) is not None:
                    return True
        return False

    def contains_integrity(self, secret_val: str, string: str) -> bool:
        # we want to ignore cases of lock files which contains hashes
        context_parts = string.split('\n')
        return any(
            len(part) < self.max_part_length and
            secret_val in part and
            self.integrity_regex.search(part) is not None for part in context_parts
        )
