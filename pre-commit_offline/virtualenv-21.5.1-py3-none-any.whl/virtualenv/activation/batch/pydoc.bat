"python.exe" -m pydoc %*
