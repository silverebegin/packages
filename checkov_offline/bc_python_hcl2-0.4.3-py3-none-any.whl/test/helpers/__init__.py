"""
Helper functions for tests
"""
