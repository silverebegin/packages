"""Version module"""
__version__ = '0.4.3'
