# -*- encoding: utf-8 -*-
# stub: securerandom 0.4.1 ruby lib

Gem::Specification.new do |s|
  s.name = "securerandom".freeze
  s.version = "0.4.1".freeze

  s.required_rubygems_version = Gem::Requirement.new(">= 0".freeze) if s.respond_to? :required_rubygems_version=
  s.metadata = { "changelog_uri" => "https://github.com/ruby/securerandom/releases", "homepage_uri" => "https://github.com/ruby/securerandom", "source_code_uri" => "https://github.com/ruby/securerandom" } if s.respond_to? :metadata=
  s.require_paths = ["lib".freeze]
  s.authors = ["Tanaka Akira".freeze]
  s.bindir = "exe".freeze
  s.date = "2026-05-20"
  s.description = "Interface for secure random number generator.".freeze
  s.email = ["akr@fsij.org".freeze]
  s.files = ["lib/securerandom.rb".freeze]
  s.homepage = "https://github.com/ruby/securerandom".freeze
  s.licenses = ["Ruby".freeze, "BSD-2-Clause".freeze]
  s.required_ruby_version = Gem::Requirement.new(">= 3.1.0".freeze)
  s.rubygems_version = "4.0.10".freeze
  s.summary = "Interface for secure random number generator.".freeze
end
