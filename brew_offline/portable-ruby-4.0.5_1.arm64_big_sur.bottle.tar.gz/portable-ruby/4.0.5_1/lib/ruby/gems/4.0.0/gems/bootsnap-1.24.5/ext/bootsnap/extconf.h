#ifndef EXTCONF_H
#define EXTCONF_H
#define HAVE_FDATASYNC 1
#define HAVE_FSTATAT 1
#endif
