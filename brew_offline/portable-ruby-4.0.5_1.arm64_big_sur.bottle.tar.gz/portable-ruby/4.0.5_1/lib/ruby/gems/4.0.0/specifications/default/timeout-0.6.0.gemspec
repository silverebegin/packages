# -*- encoding: utf-8 -*-
# stub: timeout 0.6.0 ruby lib

Gem::Specification.new do |s|
  s.name = "timeout".freeze
  s.version = "0.6.0".freeze

  s.required_rubygems_version = Gem::Requirement.new(">= 0".freeze) if s.respond_to? :required_rubygems_version=
  s.metadata = { "changelog_uri" => "https://github.com/ruby/timeout/releases", "homepage_uri" => "https://github.com/ruby/timeout", "source_code_uri" => "https://github.com/ruby/timeout" } if s.respond_to? :metadata=
  s.require_paths = ["lib".freeze]
  s.authors = ["Yukihiro Matsumoto".freeze]
  s.date = "2026-05-20"
  s.description = "Auto-terminate potentially long-running operations in Ruby.".freeze
  s.email = ["matz@ruby-lang.org".freeze]
  s.files = ["lib/timeout.rb".freeze]
  s.homepage = "https://github.com/ruby/timeout".freeze
  s.licenses = ["Ruby".freeze, "BSD-2-Clause".freeze]
  s.required_ruby_version = Gem::Requirement.new(">= 2.6.0".freeze)
  s.rubygems_version = "4.0.10".freeze
  s.summary = "Auto-terminate potentially long-running operations in Ruby.".freeze
end
